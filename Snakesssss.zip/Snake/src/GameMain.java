
public class GameMain {

	public static void main(String[] args) {
		
		 Frame f = new Frame();
		 
		
	} 

}
