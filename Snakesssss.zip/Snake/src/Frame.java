import javax.swing.JFrame;

public class Frame extends JFrame {

	Frame()
	{
		Panel p = new Panel();
		
		this.add(p);
		this.setTitle("Snake");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		this.pack();
		this.setVisible(true);
		this.setLocationRelativeTo(null);
		
		
	}
}
